# Forma Lounge Chair

Original concept study made on 10 October 2026 with AI-assisted Blender scripting, revised on 18 October 2026
(the backrest now reclines 18 degrees and the seat tilts 5 degrees; the first version's backrest leaned forward).
No client, sale, manufactured product or engineering validation is claimed.

Files: forma-lounge-chair.blend (editable scene), forma-lounge-chair.fbx (evaluated static geometry), hero/detail/clay PNGs and provenance.json.
FBX is a geometry handoff: Blender procedural shaders, studio lighting and render settings remain in the .blend.
This is a static model, without rig or animation.
