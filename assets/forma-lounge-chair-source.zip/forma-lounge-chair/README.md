# Forma Lounge Chair

Original concept study generated here on 10 October 2026 with AI-assisted Blender scripting.
No client, sale, manufactured product or engineering validation is claimed.

Files: forma-lounge-chair.blend (editable scene), forma-lounge-chair.fbx (evaluated static geometry), hero/detail/clay PNGs and provenance.json.
The speaker also includes a rear render and a separately scaled export source.

FBX is a geometry handoff: Blender procedural shaders, studio lighting and render settings remain in the .blend.
These are static models, without character rigs or animation. The concepts have not been advertised as game-ready assets.
Re-import checks are recorded in ../fbx-import-check.json. Metric FBX export scale is 0.1 metre per Blender unit.

Generation scripts are retained in D:/Money/production. Owner artistic review and manual refinement can continue from the saved scenes.
